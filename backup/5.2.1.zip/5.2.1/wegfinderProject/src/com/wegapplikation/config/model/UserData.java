package com.wegapplikation.config.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserData {
    private String username;
    private String password; // Zurück zu Klartext
    private String role;

    private static final String FILE_PATH = "wegfinderProject/src/files/user.txt";

    public UserData() {}

    public UserData(String username, String password, String role) {
        this.username = username;
        this.password = password; // Klartext
        this.role = role;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }

    public boolean isUsernameTaken(String username) {
        List<UserData> users = getAllUsers();
        return users.stream().anyMatch(user -> user.getUsername().equalsIgnoreCase(username));
    }

    public boolean verifyPassword(String username, String password) {
        List<UserData> users = getAllUsers();
        return users.stream()
                .filter(user -> user.getUsername().equalsIgnoreCase(username))
                .anyMatch(user -> user.getPassword().equals(password));
    }

    public void addUser(UserData user) {
        List<UserData> users = getAllUsers();
        users.add(user);
        saveUsers(users);
    }

    public void updateUser(String oldUsername, UserData updatedUser) {
        List<UserData> users = getAllUsers();
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equalsIgnoreCase(oldUsername)) {
                users.set(i, updatedUser);
                break;
            }
        }
        saveUsers(users);
    }

    public void deleteUser(String username) {
        List<UserData> users = getAllUsers();
        users.removeIf(user -> user.getUsername().equalsIgnoreCase(username));
        saveUsers(users);
    }

    public List<UserData> getAllUsers() {
        List<UserData> users = new ArrayList<>();
        File file = new File(FILE_PATH);
        System.out.println("Lese user.txt von: " + file.getAbsolutePath());
        if (!file.exists()) {
            System.out.println("user.txt existiert nicht!");
            return users;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                System.out.println("Verarbeite Zeile " + lineNumber + ": " + line);
                if (line.trim().isEmpty()) {
                    System.out.println("Leere Zeile in Zeile " + lineNumber + ", überspringe.");
                    continue;
                }
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    users.add(new UserData(parts[0].trim(), parts[1].trim(), parts[2].trim()));
                    System.out.println("Nutzer hinzugefügt: " + parts[0]);
                } else {
                    System.out.println("Ungültiges Format in Zeile " + lineNumber + ": " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Fehler beim Lesen von user.txt: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Geladene Nutzer: " + users.size());
        return users;
    }

    private void saveUsers(List<UserData> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (UserData user : users) {
                writer.write(user.getUsername() + "," + user.getPassword() + "," + user.getRole());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Fehler beim Schreiben in user.txt: " + e.getMessage());
            e.printStackTrace();
        }
    }
}